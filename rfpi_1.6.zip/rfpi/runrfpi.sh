#!/bin/bash
echo "Starting RFPI routine:"
/etc/rfpi/bin/rfpi