#!/bin/bash
systemctl disable bonescript.service              
systemctl disable bonescript.socket
systemctl disable bonescript-autorun.service
